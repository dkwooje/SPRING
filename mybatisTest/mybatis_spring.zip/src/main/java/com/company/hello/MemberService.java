package com.company.hello;

public interface MemberService {
	public abstract Member loginMember(Member member);
}
